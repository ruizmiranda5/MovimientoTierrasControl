
using System;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using PointCloud.Wpf3D;
using Topografia.Core.GNSS;

namespace Topografia.UI.App
{
    public class MainForm : Form
    {
        ElementHost host = new ElementHost { Dock = DockStyle.Fill };
        PointCloudViewport viewport = new PointCloud.Wpf3D.PointCloudViewport();
        TextBox txtBaseLat = new TextBox { Text="-12.0", Width=80 };
        TextBox txtBaseLon = new TextBox { Text="-77.0", Width=80 };
        TextBox txtBaseH   = new TextBox { Text="50", Width=60 };
        TextBox txtRLat = new TextBox { Text="-12.0005", Width=80 };
        TextBox txtRLon = new TextBox { Text="-77.0005", Width=80 };
        TextBox txtRH   = new TextBox { Text="51.2", Width=60 };
        Button btn = new Button { Text="Baseline RTK" };
        Label lbl = new Label { AutoSize=true };
        public MainForm(){
            Text="Topografía Profesional — NET 4.0";
            Width=1000; Height=700;
            var tabs = new TabControl{ Dock=DockStyle.Fill };
            var t3d = new TabPage("Nube 3D");
            host.Child = viewport; t3d.Controls.Add(host);
            var tgnss = new TabPage("GNSS");
            var p = new FlowLayoutPanel{ Dock=DockStyle.Fill };
            p.Controls.Add(new Label(){Text="Base Lat"}); p.Controls.Add(txtBaseLat);
            p.Controls.Add(new Label(){Text="Lon"}); p.Controls.Add(txtBaseLon);
            p.Controls.Add(new Label(){Text="h"}); p.Controls.Add(txtBaseH);
            p.Controls.Add(new Label(){Text="Rover Lat"}); p.Controls.Add(txtRLat);
            p.Controls.Add(new Label(){Text="Lon"}); p.Controls.Add(txtRLon);
            p.Controls.Add(new Label(){Text="h"}); p.Controls.Add(txtRH);
            p.Controls.Add(btn); p.Controls.Add(lbl);
            btn.Click += (s,e)=>{
                var res = GnssCalculator.BaselineFromLla((double.Parse(txtBaseLat.Text), double.Parse(txtBaseLon.Text), double.Parse(txtBaseH.Text)),
                                                         (double.Parse(txtRLat.Text), double.Parse(txtRLon.Text), double.Parse(txtRH.Text)));
                lbl.Text = string.Format("E={0:F3} N={1:F3} U={2:F3} | L={3:F3} m", res.e,res.n,res.u,res.length);
            };
            tgnss.Controls.Add(p);
            tabs.TabPages.Add(t3d); tabs.TabPages.Add(tgnss);
            Controls.Add(tabs);
        }
    }
}
