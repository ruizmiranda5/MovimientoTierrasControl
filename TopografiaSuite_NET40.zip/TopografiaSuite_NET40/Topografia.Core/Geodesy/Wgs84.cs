
using System;
namespace Topografia.Core.Geodesy
{
    public static class Wgs84
    {
        public const double a = 6378137.0;
        public const double f = 1.0 / 298.257223563;
        public static readonly double b = a * (1 - f);
        public static readonly double e2 = 1 - (b*b)/(a*a);
        public static (double X,double Y,double Z) LlaToEcef(double latDeg,double lonDeg,double h){
            double lat=latDeg*Math.PI/180.0, lon=lonDeg*Math.PI/180.0;
            double sinLat=Math.Sin(lat), cosLat=Math.Cos(lat);
            double sinLon=Math.Sin(lon), cosLon=Math.Cos(lon);
            double N=a/Math.Sqrt(1 - e2*sinLat*sinLat);
            return ((N+h)*cosLat*cosLon,(N+h)*cosLat*sinLon,(N*(1-e2)+h)*sinLat);
        }
        public static (double e,double n,double u) EcefToEnu((double X,double Y,double Z) ecef,(double latDeg,double lonDeg,double h) refLla){
            double lat=refLla.latDeg*Math.PI/180.0, lon=refLla.lonDeg*Math.PI/180.0;
            double sinPhi=Math.Sin(lat), cosPhi=Math.Cos(lat);
            double sinLam=Math.Sin(lon), cosLam=Math.Cos(lon);
            var r=LlaToEcef(refLla.latDeg,refLla.lonDeg,refLla.h);
            double dX=ecef.X-r.X, dY=ecef.Y-r.Y, dZ=ecef.Z-r.Z;
            double e = -sinLam*dX + cosLam*dY;
            double n = -sinPhi*cosLam*dX - sinPhi*sinLam*dY + cosPhi*dZ;
            double u =  cosPhi*cosLam*dX + cosPhi*sinLam*dY + sinPhi*dZ;
            return (e,n,u);
        }
    }
}
