
using Topografia.Core.Geodesy;
namespace Topografia.Core.GNSS
{
    public static class GnssCalculator
    {
        public static (double e,double n,double u,double length) BaselineFromLla((double latDeg,double lonDeg,double h) baseLla,(double latDeg,double lonDeg,double h) roverLla){
            var baseEcef=Wgs84.LlaToEcef(baseLla.latDeg,baseLla.lonDeg,baseLla.h);
            var rovEcef=Wgs84.LlaToEcef(roverLla.latDeg,roverLla.lonDeg,roverLla.h);
            var enu=Wgs84.EcefToEnu(rovEcef,baseLla);
            double len=System.Math.Sqrt(enu.e*enu.e+enu.n*enu.n+enu.u*enu.u);
            return (enu.e,enu.n,enu.u,len);
        }
    }
}
