
using System.Windows.Controls;
using System.Windows.Media.Media3D;

namespace PointCloud.Wpf3D
{
    public partial class PointCloudViewport : UserControl
    {
        public PointCloudViewport(){ InitializeComponent(); }
    }
}
