
using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Media3D;

namespace PointCloud.Wpf3D
{
    internal class Trackball
    {
        public UIElement EventSource { get; set; }
        public Transform3D Transform { get { return _transform; } }
        private Transform3DGroup _transform = new Transform3DGroup();
        private ScaleTransform3D _scale = new ScaleTransform3D();
        private AxisAngleRotation3D _rotX = new AxisAngleRotation3D(new Vector3D(1,0,0), 0);
        private AxisAngleRotation3D _rotY = new AxisAngleRotation3D(new Vector3D(0,1,0), 0);
        private TranslateTransform3D _translate = new TranslateTransform3D();
        private Point _lastPos;
        public Trackball(){ _transform.Children.Add(new RotateTransform3D(_rotY)); _transform.Children.Add(new RotateTransform3D(_rotX)); _transform.Children.Add(_scale); _transform.Children.Add(_translate); }
        public void Attach(UIElement e){ EventSource=e; e.MouseMove+=OnMouseMove; e.MouseDown+=OnMouseDown; e.MouseWheel+=OnMouseWheel; }
        void OnMouseDown(object s, MouseButtonEventArgs e){ _lastPos=e.GetPosition(EventSource); EventSource.CaptureMouse(); }
        void OnMouseMove(object s, MouseEventArgs e){ if(!EventSource.IsMouseCaptured) return; var p=e.GetPosition(EventSource); var d=p-_lastPos; _lastPos=p; if(e.LeftButton==MouseButtonState.Pressed){ _rotY.Angle += d.X*0.5; _rotX.Angle += d.Y*0.5; } else if(e.RightButton==MouseButtonState.Pressed){ _translate.OffsetX += d.X*0.01; _translate.OffsetY -= d.Y*0.01; } }
        void OnMouseWheel(object s, MouseWheelEventArgs e){ double sc=e.Delta>0?1.1:0.9; _scale.ScaleX*=sc; _scale.ScaleY*=sc; _scale.ScaleZ*=sc; }
    }
}
