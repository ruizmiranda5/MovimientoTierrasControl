# NET 4.0 build (minimal)
